import { LuPrinter } from 'react-icons/lu';
import { useStore } from '../store/store.jsx';
import { qrImageUrl, qrMetni } from '../lib/qr.js';

export default function Labels() {
  const { veri } = useStore();
  return (
    <>
      <div className="page-head">
        <div>
          <h1>QR Etiketleri</h1>
          <p>Yazdırıp kazanların yan yüzüne yapıştırın. Büyük kod yazısı, QR okunamazsa AI'ın etiketten kazanı tanıması içindir.</p>
        </div>
        <button className="btn btn-primary" onClick={() => window.print()}><LuPrinter /> Yazdır</button>
      </div>
      <div className="labels">
        {veri.kazanlar.map((k) => (
          <div className="label-card" key={k.id}>
            <img src={qrImageUrl(qrMetni(k.id))} alt={`${k.id} QR kodu`} loading="lazy" />
            <div className="kod">{k.id}</div>
            <small>{k.ad} · {k.hacimL} L</small>
            <div className="mono small muted" style={{ marginTop: 4 }}>{qrMetni(k.id)}</div>
          </div>
        ))}
      </div>
    </>
  );
}
